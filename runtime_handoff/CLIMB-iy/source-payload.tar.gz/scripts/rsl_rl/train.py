# Copyright (c) 2025-2026, Junjie Zhu.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Script to train RL agent with RSL-RL."""

"""Launch Isaac Sim Simulator first."""

import argparse
import sys

from isaaclab.app import AppLauncher

# local imports
import cli_args  # isort: skip

# add argparse arguments
parser = argparse.ArgumentParser(description="Train an RL agent with RSL-RL.")
parser.add_argument("--video", action="store_true", default=False, help="Record videos during training.")
parser.add_argument("--video_length", type=int, default=200, help="Length of the recorded video (in steps).")
parser.add_argument("--video_interval", type=int, default=2000, help="Interval between video recordings (in steps).")
parser.add_argument("--num_envs", type=int, default=None, help="Number of environments to simulate.")
parser.add_argument("--task", type=str, default=None, help="Name of the task.")
parser.add_argument(
    "--agent", type=str, default="rsl_rl_cfg_entry_point", help="Name of the RL agent configuration entry point."
)
parser.add_argument("--seed", type=int, default=None, help="Seed used for the environment")
parser.add_argument("--max_iterations", type=int, default=None, help="RL Policy training iterations.")
parser.add_argument("--push-action-sampling", choices=("all", "active"), help="PIPER Tracking diagnostic: record action activity and optionally train only on controllable states.")
parser.add_argument(
    "--push-ik-clearance-minimum", type=float,
    help="PIPER Tracking: use the same optional IK clearance projection as evaluation.",
)
initialization_group = parser.add_mutually_exclusive_group()
initialization_group.add_argument("--init_checkpoint", type=str, help="Initialize models from a trusted project checkpoint without optimizer or iteration state.")
initialization_group.add_argument("--init_actor", type=str, help="Initialize an actor from trusted project TorchScript, preserving its input prefix.")
initialization_group.add_argument("--init_leg_actor", type=str, help="Initialize the 12 leg outputs from the project's 18-action NAV TorchScript.")
initialization_group.add_argument("--init_nav_for_climb", type=str, help="Project a 210-input NAV actor onto the 253-input single-frame CLIMB observation contract.")
parser.add_argument(
    "--initial_std", type=float,
    help="Override exploration standard deviation; checkpoints preserve their value by default.",
)
parser.add_argument(
    "--distributed", action="store_true", default=False, help="Run training with multiple GPUs or nodes."
)
parser.add_argument("--export_io_descriptors", action="store_true", default=False, help="Export IO descriptors.")
parser.add_argument(
    "--ray-proc-id", "-rid", type=int, default=None, help="Automatically configured by Ray integration, otherwise None."
)
# append RSL-RL cli arguments
cli_args.add_rsl_rl_args(parser)
# append AppLauncher cli args
AppLauncher.add_app_launcher_args(parser)
args_cli, hydra_args = parser.parse_known_args()
if args_cli.push_ik_clearance_minimum is not None:
    if args_cli.task != "GO2-PIPER-Box-Push-Tracking" or not 0.08 < args_cli.push_ik_clearance_minimum <= 0.15:
        parser.error("IK clearance requires PIPER Tracking and a distance in (0.08, 0.15]")

# always enable cameras to record video
if args_cli.video:
    args_cli.enable_cameras = True

# clear out sys.argv for Hydra
sys.argv = [sys.argv[0]] + hydra_args

# launch omniverse app
app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

"""Check for minimum supported RSL-RL version."""

import importlib.metadata as metadata
import platform

from packaging import version

# check minimum supported rsl-rl version
RSL_RL_VERSION = "3.0.1"
installed_version = metadata.version("rsl-rl-lib")
if version.parse(installed_version) < version.parse(RSL_RL_VERSION):
    if platform.system() == "Windows":
        cmd = [r".\isaaclab.bat", "-p", "-m", "pip", "install", f"rsl-rl-lib=={RSL_RL_VERSION}"]
    else:
        cmd = ["./isaaclab.sh", "-p", "-m", "pip", "install", f"rsl-rl-lib=={RSL_RL_VERSION}"]
    print(
        f"Please install the correct version of RSL-RL.\nExisting version is: '{installed_version}'"
        f" and required version is: '{RSL_RL_VERSION}'.\nTo install the correct version, run:"
        f"\n\n\t{' '.join(cmd)}\n"
    )
    exit(1)

"""Rest everything follows."""

import logging
import os
import time
from datetime import datetime

import gymnasium as gym
import torch
from rsl_rl.runners import DistillationRunner, OnPolicyRunner

from isaaclab.envs import (
    DirectMARLEnv,
    DirectMARLEnvCfg,
    DirectRLEnvCfg,
    ManagerBasedRLEnvCfg,
    multi_agent_to_single_agent,
)
from isaaclab.utils.dict import print_dict
from isaaclab.utils.io import dump_yaml

from isaaclab_rl.rsl_rl import RslRlBaseRunnerCfg, RslRlVecEnvWrapper, handle_deprecated_rsl_rl_cfg

import isaaclab_tasks  # noqa: F401
from isaaclab_tasks.utils import get_checkpoint_path
from isaaclab_tasks.utils.hydra import hydra_task_config

# import logger
logger = logging.getLogger(__name__)

import LeggedManip_Lab.tasks  # noqa: F401

torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True
torch.backends.cudnn.deterministic = False
torch.backends.cudnn.benchmark = False


@hydra_task_config(args_cli.task, args_cli.agent)
def main(env_cfg: ManagerBasedRLEnvCfg | DirectRLEnvCfg | DirectMARLEnvCfg, agent_cfg: RslRlBaseRunnerCfg):
    """Train with RSL-RL agent."""
    # override configurations with non-hydra CLI arguments
    agent_cfg = cli_args.update_rsl_rl_cfg(agent_cfg, args_cli)
    if args_cli.push_ik_clearance_minimum is not None:
        env_cfg.push_ik_clearance_minimum = args_cli.push_ik_clearance_minimum
    env_cfg.scene.num_envs = args_cli.num_envs if args_cli.num_envs is not None else env_cfg.scene.num_envs
    agent_cfg.max_iterations = (
        args_cli.max_iterations if args_cli.max_iterations is not None else agent_cfg.max_iterations
    )

    # handle deprecated configurations
    agent_cfg = handle_deprecated_rsl_rl_cfg(agent_cfg, installed_version)

    # set the environment seed
    # note: certain randomizations occur in the environment initialization so we set the seed here
    env_cfg.seed = agent_cfg.seed
    env_cfg.sim.device = args_cli.device if args_cli.device is not None else env_cfg.sim.device
    # check for invalid combination of CPU device with distributed training
    if args_cli.distributed and args_cli.device is not None and "cpu" in args_cli.device:
        raise ValueError(
            "Distributed training is not supported when using CPU device. "
            "Please use GPU device (e.g., --device cuda) for distributed training."
        )

    # multi-gpu training configuration
    if args_cli.distributed:
        env_cfg.sim.device = f"cuda:{app_launcher.local_rank}"
        agent_cfg.device = f"cuda:{app_launcher.local_rank}"

        # set seed to have diversity in different threads
        seed = agent_cfg.seed + app_launcher.local_rank
        env_cfg.seed = seed
        agent_cfg.seed = seed

    # specify directory for logging experiments
    log_root_path = os.path.join("logs", "rsl_rl", agent_cfg.experiment_name)
    log_root_path = os.path.abspath(log_root_path)
    print(f"[INFO] Logging experiment in directory: {log_root_path}")
    # specify directory for logging runs: {time-stamp}_{run_name}
    log_dir = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    # The Ray Tune workflow extracts experiment name using the logging line below, hence, do not
    # change it (see PR #2346, comment-2819298849)
    print(f"Exact experiment name requested from command line: {log_dir}")
    if agent_cfg.run_name:
        log_dir += f"_{agent_cfg.run_name}"
    log_dir = os.path.join(log_root_path, log_dir)

    # set the IO descriptors export flag if requested
    if isinstance(env_cfg, ManagerBasedRLEnvCfg):
        env_cfg.export_io_descriptors = args_cli.export_io_descriptors
    else:
        logger.warning(
            "IO descriptors are only supported for manager based RL environments. No IO descriptors will be exported."
        )

    # set the log directory for the environment (works for all environment types)
    env_cfg.log_dir = log_dir
    if args_cli.push_action_sampling:
        if (args_cli.task != "GO2-PIPER-Box-Push-Tracking" or args_cli.distributed
                or agent_cfg.class_name != "OnPolicyRunner"
                or getattr(env_cfg, "push_body_first", False)
                or getattr(env_cfg, "push_full_body_preapproach", False)
                or getattr(env_cfg, "push_precontact_heights", ())):
            raise ValueError("Action sampling requires ordinary single-GPU PIPER Tracking")
        env_cfg.record_push_policy_activity = True

    # create isaac environment
    env = gym.make(args_cli.task, cfg=env_cfg, render_mode="rgb_array" if args_cli.video else None)

    if args_cli.init_nav_for_climb:
        expected_terms = ("base_lin_vel", "base_ang_vel", "projected_gravity", "velocity_commands", "joint_pos", "joint_vel", "actions", "height_scan")
        if tuple(env.unwrapped.observation_manager.active_terms["policy"]) != expected_terms:
            raise ValueError("NAV-to-CLIMB observation terms do not match the projection")
        for name in expected_terms[:-1]:
            if getattr(env_cfg.observations.policy, name).scale not in (None, 1.0):
                raise ValueError(f"Unexpected CLIMB observation scale: {name}")
    if args_cli.init_checkpoint or args_cli.init_actor or args_cli.init_leg_actor or args_cli.init_nav_for_climb:
        robot = env.unwrapped.scene["robot"]
        print(f"[SKILL] Bodies: {robot.body_names}")
        print(f"[SKILL] Joints: {robot.joint_names}")
        print(f"[SKILL] Effort limits: {robot.data.joint_effort_limits[0].tolist()}")
        for name, actuator in robot.actuators.items():
            print(f"[SKILL] Actuator {name}: effort={actuator.effort_limit[0].tolist()} velocity={actuator.velocity_limit[0].tolist()}")
        from pxr import Usd, UsdPhysics

        stage = Usd.Stage.Open(robot.cfg.spawn.usd_path)
        colliders = {}
        for prim in stage.Traverse(Usd.TraverseInstanceProxies()):
            if prim.HasAPI(UsdPhysics.CollisionAPI):
                owner = prim
                while owner.IsValid() and not owner.HasAPI(UsdPhysics.RigidBodyAPI):
                    owner = owner.GetParent()
                if owner.IsValid():
                    colliders.setdefault(owner.GetName(), []).append(prim.GetName())
        print(f"[SKILL] Collision owners: {colliders}")
        if "box" in env.unwrapped.scene.rigid_objects:
            box = env.unwrapped.scene["box"]
            masses = box.root_physx_view.get_masses()
            materials = box.root_physx_view.get_material_properties()
            print(f"[SKILL] Box mass range: {masses.min().item():.4f}..{masses.max().item():.4f}")
            print(f"[SKILL] Box sliding friction range: {materials[:, :, 1].min().item():.4f}..{materials[:, :, 1].max().item():.4f}")

    # convert to single-agent instance if required by the RL algorithm
    if isinstance(env.unwrapped, DirectMARLEnv):
        env = multi_agent_to_single_agent(env)

    # save resume path before creating a new log_dir
    if agent_cfg.resume or agent_cfg.algorithm.class_name == "Distillation":
        resume_path = get_checkpoint_path(log_root_path, agent_cfg.load_run, agent_cfg.load_checkpoint)

    # wrap for video recording
    if args_cli.video:
        video_kwargs = {
            "video_folder": os.path.join(log_dir, "videos", "train"),
            "step_trigger": lambda step: step % args_cli.video_interval == 0,
            "video_length": args_cli.video_length,
            "disable_logger": True,
        }
        print("[INFO] Recording videos during training.")
        print_dict(video_kwargs, nesting=4)
        env = gym.wrappers.RecordVideo(env, **video_kwargs)

    start_time = time.time()

    # wrap around environment for rsl-rl
    env = RslRlVecEnvWrapper(env, clip_actions=agent_cfg.clip_actions)

    # create runner from rsl-rl
    if agent_cfg.class_name == "OnPolicyRunner":
        runner = OnPolicyRunner(env, agent_cfg.to_dict(), log_dir=log_dir, device=agent_cfg.device)
    elif agent_cfg.class_name == "DistillationRunner":
        runner = DistillationRunner(env, agent_cfg.to_dict(), log_dir=log_dir, device=agent_cfg.device)
    else:
        raise ValueError(f"Unsupported runner class: {agent_cfg.class_name}")
    # write git state to logs
    runner.add_git_repo_to_log(__file__)
    if args_cli.init_checkpoint or args_cli.init_actor or args_cli.init_leg_actor or args_cli.init_nav_for_climb:
        from initialization import initialize_models

        if agent_cfg.resume:
            raise ValueError("Model initialization and training resume are mutually exclusive")
        initialized = initialize_models(
            runner.alg.actor, runner.alg.critic,
            checkpoint_path=args_cli.init_checkpoint, actor_path=args_cli.init_actor or args_cli.init_leg_actor or args_cli.init_nav_for_climb,
            initial_std=args_cli.initial_std,
            action_indices=list(range(12)) if args_cli.init_leg_actor else None,
            observation_layout="nav_to_climb" if args_cli.init_nav_for_climb else "prefix",
        )
        print(f"[SKILL] Initialized new task models: {initialized}")
    # load the checkpoint
    if agent_cfg.resume or agent_cfg.algorithm.class_name == "Distillation":
        print(f"[INFO]: Loading model checkpoint from: {resume_path}")
        # load previously trained model
        runner.load(resume_path)

    # dump the configuration into log-directory
    if args_cli.push_action_sampling:
        import hashlib
        import json
        from push_action_sampling import install_push_action_sampling

        install_push_action_sampling(runner.alg, active_only=args_cli.push_action_sampling == "active")
        sampling_path = os.path.join(os.path.dirname(__file__), "push_action_sampling.py")
        with open(sampling_path, "rb") as source:
            sampling_sha256 = hashlib.sha256(source.read()).hexdigest()
        os.makedirs(log_dir, exist_ok=True)
        with open(os.path.join(log_dir, "push_action_sampling.json"), "w") as output:
            json.dump({"mode": args_cli.push_action_sampling, "source_sha256": sampling_sha256,
                       "returns": "complete_trajectory", "loss_samples": "actor_critic_entropy"}, output, indent=2)
    dump_yaml(os.path.join(log_dir, "params", "env.yaml"), env_cfg)
    dump_yaml(os.path.join(log_dir, "params", "agent.yaml"), agent_cfg)

    # run training
    runner.learn(num_learning_iterations=agent_cfg.max_iterations, init_at_random_ep_len=True)

    print(f"Training time: {round(time.time() - start_time, 2)} seconds")

    # close the simulator
    env.close()


if __name__ == "__main__":
    # run the main function
    main()
    # close sim app
    simulation_app.close()
