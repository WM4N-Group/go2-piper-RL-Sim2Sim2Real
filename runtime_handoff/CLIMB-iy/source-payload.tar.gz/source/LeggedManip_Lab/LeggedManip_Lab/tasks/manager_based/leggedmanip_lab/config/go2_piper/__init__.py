import gymnasium as gym
from . import agents

# Flat
gym.register(
    id="GO2-PIPER-Flat",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.flat_env_cfg:Go2PiperFlatEnvCfg",
        "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:Go2PiperFlatPPORunnerCfg",
    },
)

gym.register(
    id="GO2-PIPER-Flat-Play",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.flat_env_cfg:Go2PiperFlatEnvCfg_PLAY",
        "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:Go2PiperFlatPPORunnerCfg",
    },
)

# WBC
gym.register(
    id="GO2-PIPER-WBC",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.wbc_env_cfg:Go2PiperWBCEnvCfg",
        "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:Go2PiperWBCPPORunnerCfg",
    },
)

gym.register(
    id="GO2-PIPER-WBC-Play",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.wbc_env_cfg:Go2PiperWBCEnvCfg_PLAY",
        "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:Go2PiperWBCPPORunnerCfg",
    },
)

for task, environment, runner in (
    ("Box-Push-Hybrid", "Go2PiperBoxPushHybridEnvCfg", "Go2PiperBoxPushHybridPPORunnerCfg"),
    ("Box-Push-Tracking", "Go2PiperBoxPushTrackingEnvCfg", "Go2PiperBoxPushHybridPPORunnerCfg"),
    ("Box-Push-Low", "Go2PiperBoxPushLowEnvCfg", "Go2PiperBoxPushLowPPORunnerCfg"),
    ("Box-Push-Safe-Base", "Go2PiperBoxPushSafeBaseEnvCfg", "Go2PiperBoxPushSafeBasePPORunnerCfg"),
    ("Box-Climb", "Go2PiperBoxClimbEnvCfg", "Go2PiperBoxClimbPPORunnerCfg"),
    ("Box-Climb-Smooth", "Go2PiperBoxClimbSmoothEnvCfg", "Go2PiperBoxClimbPPORunnerCfg"),
    ("Box-Climb-Stages", "Go2PiperBoxClimbStagesEnvCfg", "Go2PiperBoxClimbPPORunnerCfg"),
    ("Box-Climb-Crawl", "Go2PiperBoxClimbCrawlEnvCfg", "Go2PiperBoxClimbPPORunnerCfg"),
    ("Box-Climb-Robust", "Go2PiperBoxClimbRobustEnvCfg", "Go2PiperBoxClimbPPORunnerCfg"),
    ("Box-Climb-Contact-Robust", "Go2PiperBoxClimbContactRobustEnvCfg", "Go2PiperBoxClimbPPORunnerCfg"),
):
    for suffix, config_suffix in (("", ""), ("-Play", "_PLAY")):
        gym.register(
            id=f"GO2-PIPER-{task}{suffix}",
            entry_point="isaaclab.envs:ManagerBasedRLEnv",
            disable_env_checker=True,
            kwargs={
                "env_cfg_entry_point": f"{__name__}.box_env_cfg:{environment}{config_suffix}",
                "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:{runner}",
            },
        )
